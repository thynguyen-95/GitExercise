package com.company;

import static org.junit.jupiter.api.Assertions.*;

class StudentAppTest {

    @org.junit.jupiter.api.Test
    void sort1() {
    }
}