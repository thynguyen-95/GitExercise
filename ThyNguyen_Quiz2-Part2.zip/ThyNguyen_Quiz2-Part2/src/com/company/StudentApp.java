package com.company;

import java.util.HashMap;
import java.util.*;
import java.io.*;
import java.nio.file.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;
import static java.nio.file.StandardOpenOption.CREATE;


public class StudentApp {

    static int number;
    static String name;
    static double grade;

    static HashMap<String, Student> stRecord = new HashMap<String, Student>();
    static Scanner sc = new Scanner(System.in);
    static  ArrayList<Student> records = new ArrayList<Student>();


    public static void main(String[] args) throws IOException {

        //System.out.println("Welcome, please press enter");

        ArrayList<Student> records = new ArrayList<Student>();
      //ap1(;

        System.out.println("Welcome to the StudentBook program ");


        String ch= sc.nextLine(); //user choices

        while (true){
             hashMap1();
             ch = sc.nextLine().toUpperCase();
            //System.out.println("(A)dd, (R)emove, (M)odify, (P)rint all, (S)ort or (Q)uit");

             switch (ch){

                 case "A":
                     add1();
                     break;

                 case "R":
                     remove1();
                     break;

                 case "M":
                     modify1();
                     break;

                 case "P":
                     printAll();
                     break;

                 case "S":

                     sort1();
                     break;

                 case "Q":
                     System.exit(0);
                     break;

                 default:
                     System.out.println("Invalid choice. Please choose again!");

             }

        }

    }

    public static void sort1() {
        for (Map.Entry<String,Student> entry: stRecord.entrySet()){
            //System.out.println(" "+ entry.getKey() + ": " + entry.getValue());
            Collections.sort(entry.getValue());
            break;

        }

    }

    public static void printAll() {

        count(records);
      for (Map.Entry<String,Student> entry: stRecord.entrySet()){
            System.out.println(" "+ entry.getKey() + ": " + entry.getValue());
            break;

        }



    }

    //method to count the number of record in the Student List
    public static void count(ArrayList<Student> records){
        System.out.println("There are currently " + records.size() + " in your class list");

        for(int i=0; i<records.size(); ++i){
            System.out.println(records.get(i));}

    }
    public static void modify1() throws IOException {


        //boolean check = true;
       // int check = ExistingContact(stRecord,name);

        File tempfile = new File("tempfile.txt");
        File temp1 = new File("temp1.txt");

        BufferedWriter writer = new BufferedWriter(new FileWriter(temp1));
        Scanner sc = new Scanner(tempfile);

        System.out.println("Enter the student number ");
        Scanner sc1 = new Scanner(System.in);
        number= sc1.nextInt();

        System.out.println("Enter the student name ");
        name= sc1.nextLine();

        System.out.println("Enter the student grade you want to modify ");
        double grade = sc1.nextDouble();


        while(sc.hasNextLine()){
         Student newRecord = new Student(number, name, grade);
        // stRecord.put(check,newRecord);
        }


    }



    public static void remove1() throws IOException {
        if(stRecord != null){
            int count = stRecord.size();
            try {
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                System.out.println("Enter the student number:");
                int key= br.read();
                System.out.print("Do you really want to delete this record? Y/N ");

                String ch= sc.nextLine(); //user enter choice
                ch = sc.nextLine().toUpperCase();

                if(ch=="Y") {
                    stRecord.remove(key);//DELETE the record
                }


            }

            catch(Exception e){
                System.out.println(e.getMessage());
            }
        }
    }

    public static void add1() {
        ArrayList<Student> records = new ArrayList<Student>();

        if (stRecord == null) stRecord = new HashMap<String, Student>();
//        File tempfile = new File("tempfile.txt");

       // Properties proper = new Properties();
        //InputStream input = null;

        int number = 0;
        String name= " ", record = " ";
        double grade = 0.0;
        BufferedWriter output = null;

        try{
            //OutputStream output = new BufferedOutputStream(File.createTempFile(tempfile, CREATE));
           //boolean newFile= dir.mkdir();
           File tempfile = new File("tempfile.txt");
           output = new BufferedWriter(new FileWriter(tempfile));
           output.write();
         //  input = new FileInputStream(tempfile.getPath());
          // proper.load(input);

            // newFile = tempfile.createNewFile();
           do {
               System.out.println("Enter the student number ");
               number = sc.nextInt();

               System.out.println("Enter the student name ");
               name = sc.nextLine();

               System.out.println("Enter the student grade ");
               grade = sc.nextDouble();

               System.out.println("Record Updated");

               record = "Student Number "+ number +"\n"+ "Student Name" + name+ "\n" + "The grade is " + grade ;

               Student st1 = new Student(number, name, grade);
               stRecord.put(name,st1);








           }
           while(!name.equals("Q"));
           //input.close();


        }
        catch (IOException e) {
            System.out.println("Something wrong, please try again");;
        }

    }

    public static void hashMap1() {

        HashMap<String, String> choices = new HashMap<String, String>();


        choices.put("A", "dd");
        choices.put("R", "emove");
        choices.put("M", "odify");
        choices.put("P", "rint all");
        choices.put("S", "ort");
        choices.put("Q", "uit");

        for (Map.Entry<String, String> entry: choices.entrySet()){
         //   for(int i = 0; i< choices.get(entry.getKey()).length(); --i ) {
                System.out.print(" "   + "[" + entry.getKey()+"]" + choices.get(entry.getKey()) + ""
                );

            }



    }
}
